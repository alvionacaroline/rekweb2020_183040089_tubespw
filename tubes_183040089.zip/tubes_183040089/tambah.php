<?php

	require 'functions.php';

	if( isset($_POST["tambah"]) ) {
	
	// cek apakah data berhasil di tambahkan atau tidak
	if( tambah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil ditambahkan!');
				document.location.href = 'admin/index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal ditambahkan!');
				document.location.href = 'admin/index.php';
			</script>
		";
	}
}

?>


<!DOCTYPE html>
<html>
<head>
	  <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Tambah Data Smartphone</title>
	<style>
		h1 {
			text-align: center;
			font-family: forte;
		}

		body {
			background-color: #bdbdbd;
			padding: 20px;
		}

		.card-panel {
			box-shadow: 0px 0px 10px black;
			background-color: lavender;
		}
	</style>
</head>
<body>

<div class="container">
	<div class="col s6">
        <form action="" method="post" enctype="multipart/form-data">
        	<div class="card-panel">
        		<h1>Tambah Data Smartphone</h1>

                <label for="Nama_Smartphone">Nama Smartphone</label>
				<input type="text" name="Nama_Smartphone" id="Nama_Smartphone"><br><br>

				<label for="Gambar">Gambar</label><br><br>
				<input type="file" name="Gambar" id="Gambar"><br><br>

				<label for="Warna">Warna</label>
				<input type="text" name="Warna" id="Warna"><br><br>

				<label for="Ukuran_Layar">Ukuran Layar</label>
				<input type="text" name="Ukuran_Layar" id="Ukuran_Layar"><br><br>

				<label for="Berat">Berat</label>
				<input type="text" name="Berat" id="Berat"><br><br>

				<label for="Tahun_Rilis">Tahun Rilis</label>
				<input type="text" name="Tahun_Rilis" id="Tahun_Rilis"><br><br>

				<label for="Harga">Harga</label>
				<input type="text" name="Harga" id="Harga"><br><br><br>

				<button type="sumbit" name="tambah" id="tambah" class="btn blue darken-2">Tambah Data</button>
            </div>
        </form>
    </div>
</div>

	<!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="js/materialize.min.js"></script>
</body>
</html>