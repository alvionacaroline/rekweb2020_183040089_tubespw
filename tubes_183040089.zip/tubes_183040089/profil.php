<?php 

if (!isset($_GET['id'])) {
	header("Location : index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$a = query("SELECT * FROM smartphone WHERE id = $id")[0];

?>


<!DOCTYPE html>
<html>
<head>
	<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

	<title>index Halaman Admin</title>
	<style>
		body {
			background-color: #9e9e9e;
		}

		.back {
			background-color: #424242;
			padding: 1px;
			border-radius: 10px;
			width: 100px;
			text-align: center;
			margin: auto;
			margin-top: 50px;
		}

		a {
			font-size: 20px;
			font-family: arial;
			text-decoration: none;
			color: white;
		}

		.container {
			width: 350px;
			font-family: arial;
		}

		.card {
			background-color: #424242;
			box-shadow: 0 0 15px #37474f;
			border-radius: 10px;
		}

		.card-content {
			color: #e0e0e0;
		}

		img {
			padding: 20px;
		}

		p {
			text-align: center;
		}

		h1 {
			font-family: forte;
		}
</style>
 </head>
 <body>
 	<h1 align="center">Spesifikasi Smartphone</h1>
 	<div class="container">
 		 <div class="card">
    		<div class="card-image waves-effect waves-block waves-light">
     			<img src="assets/images/<?= $a["Gambar"]; ?>">
    		</div>
    		<div class="card-content">
    			<span class="card-title activator text-lighten-3"><?= $a['Nama_Smartphone']; ?><i class="material-icons right">more_vert</i></span>
 			</div>
    		<div class="card-reveal">
    			<span class="card-title grey-text text-darken-4"><i class="material-icons right">close</i></span>
     			<h4 align="center">Spesifikasi</h4>
     			<br>
     			<p>Warna : <?= $a["Warna"]; ?></p>
     			<p>Ukuran Layar : <?= $a["Ukuran_Layar"]; ?></p>
     			<p>Berat : <?= $a["Berat"]; ?></p>
     			<p>Tahun Rilis : <?= $a["Tahun_Rilis"]; ?></p>
     			<p>Harga : <?= $a["Harga"]; ?></p>
    		</div>
 			</div>

 			<h4 class="back">
				<a href="index.php">Kembali</a>
			</h4>
 
<!--JavaScript at end of body for optimized loading-->
<script type="text/javascript" src="js/materialize.min.js"></script>

</body>
</html>