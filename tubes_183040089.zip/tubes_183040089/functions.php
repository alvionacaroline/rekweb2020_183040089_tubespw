<?php 

function koneksi()
{
	$conn = mysqli_connect("localhost", "root", "") or die("Koneksi Gagal!");
	mysqli_select_db($conn, "pw_183040089") or die("DB Salah!");

	return $conn;
}


function query($sql)
{
	$conn = koneksi();
	$results = mysqli_query($conn, "$sql");

	$rows = [];
	while ($row = mysqli_fetch_assoc($results)) {
		$rows[] = $row;
	};

	return $rows;
}


function tambah($data) {
	$conn = koneksi();

	$Nama_Smartphone = htmlspecialchars($data['Nama_Smartphone']);
	$Warna = htmlspecialchars($data['Warna']);
	$Ukuran_Layar = htmlspecialchars($data['Ukuran_Layar']);
	$Berat = htmlspecialchars($data['Berat']);
	$Tahun_Rilis = htmlspecialchars($data['Tahun_Rilis']);
	$Harga = htmlspecialchars($data['Harga']);

	// upload gambar
	$Gambar =upload();
	if(!$Gambar) {
		return false;
	}


	$query_tambah = "INSERT INTO smartphone VALUES ('', '$Nama_Smartphone', '$Gambar', '$Warna', '$Ukuran_Layar', '$Berat', '$Tahun_Rilis', '$Harga')";

	mysqli_query($conn, $query_tambah);

	return mysqli_affected_rows($conn);
}


function upload() {
	$namaFile = $_FILES['Gambar']['name'];
	$ukuranFile = $_FILES['Gambar']['size'];
	$error = $_FILES['Gambar']['error'];
	$tmpName = $_FILES['Gambar']['tmp_name'];

	// cek apakah tidak ada gambar yang di upload
	if($error === 4) {
		echo "<script>
		alert('pilih gambar terlebih dahulu!');
		</script>";

		return false;
	}

	// cek apakah yang di upload adalah gambar

	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if( !in_array($ekstensiGambar, $ekstensiGambarValid) ) {
		echo "<script>
		alert('yang anda upload bukan gambar!');
		</script>";
		return false;
	}

	// cek jika ukurannya terlalu besar
	if($ukuranFile > 1000000) {
		echo "<script>
		alert('ukuran gambar terlalu besar!');
		</script>";
		return false;
	}

	// lolos pengecekan, gambar siap di upload
	// generate nama gambar baru
	$namaFileBaru = uniqid();
	$namaFileBaru .= '.';
	$namaFileBaru .= $ekstensiGambar;

	move_uploaded_file($tmpName, 'assets/images/'. $namaFileBaru);

	return $namaFileBaru;
}

function hapus($id) {
	$conn = koneksi();
	mysqli_query($conn, "DELETE FROM smartphone WHERE id = $id");

	return mysqli_affected_rows($conn);
}


function ubah($data){
	$conn = koneksi();

	$id = $data['id'];
	$Nama_Smartphone = htmlspecialchars($data['Nama_Smartphone']);

	$gambarLama = htmlspecialchars($data['gambarLama']);

	// cek apakah user pilih gambar baru atau tidak
	if($_FILES['Gambar']['error'] === 4) {
		$Gambar = $gambarLama;
	} else {
		$Gambar = upload();
	}

	$Warna = htmlspecialchars($data['Warna']);
	$Ukuran_Layar = htmlspecialchars($data['Ukuran_Layar']);
	$Berat = htmlspecialchars($data['Berat']);
	$Tahun_Rilis = htmlspecialchars($data['Tahun_Rilis']);
	$Harga = htmlspecialchars($data['Harga']);
	

	$query_ubah = "UPDATE smartphone SET
					Nama_Smartphone = '$Nama_Smartphone',
					Gambar = '$Gambar',
					Warna = '$Warna',
					Ukuran_Layar = '$Ukuran_Layar',
					Berat = '$Berat',
					Tahun_Rilis = $Tahun_Rilis,
					Harga = '$Harga'
					WHERE id = $id
					";

	mysqli_query($conn, $query_ubah);

	return mysqli_affected_rows($conn);
}


function cari($keyword) {
	$query = "SELECT * FROM smartphone
	WHERE
	Nama_Smartphone LIKE '%$keyword%' OR
	Warna LIKE '%$keyword%' OR
	Ukuran_Layar LIKE '%$keyword%' OR
	Berat LIKE '%$keyword%' OR
	Tahun_Rilis LIKE '%$keyword%' OR
	Harga LIKE '%$keyword%'
	";

	return query($query);
}

?>

