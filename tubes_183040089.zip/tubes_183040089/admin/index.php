<?php 

require '../functions.php';

if(isset($_POST["cari"]) ) {
	$smartphone = cari($_POST["keyword"]);
} else {
  $smartphone = query("SELECT * FROM smartphone");
}

?>


<!DOCTYPE html>
<html>
<head>
	<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>

      <script type="text/javascript" src="../js/jquery-3.3.1.min.js"></script>

	<title>Halaman Admin</title>
	<style>
		td {
			text-align: center;
		}

		th {
			text-align: center;
		}

		.container1 {
			background-color: #bdbdbd;
		}

		body {
			background-color: #757575;
		}

		h1 {
			font-family: forte;
		}

		.hapus {
			color: #3CB371;
		}

		.ubah {
			color: #E9967A;
		}

		.data {
    	  text-align: center;
    	  font-family: arial;
    	  color: red;
    	  font-style: italic;
    	  padding: 10px;
    	  background-color: white;
    	  width: 500px;
    	  margin: auto;
    	  border-radius: 8px;
    	  box-shadow: 5px 5px 5px black;
    	}
	</style>
</head>
<body>

	<!-- navbar -->
      <div class="navbar-fixed">
      <nav class="#424242 grey darken-3">
        <div class="container">
         <div class="nav-wrapper">
         	<ul class="brand-logo center">
         		<li>
         			<a href="index.php"><i class="material-icons">home</i></a>
         		</li>
         	</ul>
         	<ul class="right hide-on-med-and-down">
         		<li><a href="../tambah.php"><i class="material-icons">add_to_photos</i></a></li>
         		<li><a href="../index.php"><i class="material-icons">input</i></a></li>
         	</ul>
         	<ul class="left hide-on-med-and-down">
         		<li>
         			<form action="" method="post" class="search">
         			<i class="material-icons">search
					<input type="text" name="keyword" autofocus placeholder="Search..." autocomplete="off"></i>
					<button type="submit" name="cari" style="display: none;">Cari</button>
					</form>
         		</li>
         	</ul>
          </div>
        </div>
      </nav>
      </div>
      <!-- Tutup navbar -->

       <h1 align="center">Macam-Macam Smartphone</h1>

       <?php if (empty($smartphone)) :?>
    		<tr>
				<td>
    				<h3 class="data">Data Tidak Ditemukan!</h3>
          		</td>
        	</tr>
     	<?php else : ?>

       <div class="container1">

        <table class="highlight">

         <tr>
			<th>No</th>
			<th>Opsi</th>
			<th>Nama Smartphone</th>
			<th>Gambar</th>
			<th>Warna</th>
			<th>Ukuran Layar</th>
			<th>Berat</th>
			<th>Tahun Rilis</th>
			<th>Harga</th>
		</tr>

		<?php $no = 1; ?>
		<?php foreach ($smartphone as $hp): ?>
			
			<tr>
				<td><?php echo $no++; ?></td>

				<td>
					<a class="hapus" href="../hapus.php?id=<?= $hp['id']; ?>" onclick="return confirm('yakin?');"><i class="material-icons">delete</i></a>
					<a class="ubah" href="../ubah.php?id=<?= $hp['id']; ?>"><i class="material-icons">mode_edit</i></a>
				</td>

				<td>
					<?php echo $hp['Nama_Smartphone']; ?>
				</td>

				<td align="center">
					<img width="100px" align="center" src="../assets/images/<?= $hp['Gambar'] ?>">
				</td>

				<td>
					<?php echo $hp['Warna']; ?>
				</td>

				<td>
					<?php echo $hp['Ukuran_Layar']; ?>
				</td>

				<td>
					<?php echo $hp['Berat']; ?>
				</td>

				<td>
					<?php echo $hp['Tahun_Rilis']; ?>
				</td>

				<td>
					<?php echo $hp['Harga']; ?>
				</td>

			</tr>
			<?php endforeach ?>
		<?php endif ?>

    	</table>
    </div>

	<!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="../js/materialize.min.js"></script>
</body>
</html>