<?php 	
if( isset($_POST["submit"])){
	if ($_POST["username"] == "admin" && $_POST["password"] == "admin"){
		header("Location: index.php");
		exit;
	} else {
		$error = true;
	}
}

 ?>
<!DOCTYPE html>
<html>
<head>
		<!--Import Google Icon Font-->
    	<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
    	<!--Import materialize.css-->
    	<link type="text/css" rel="stylesheet" href="../css/materialize.min.css"  media="screen,projection"/>

    	<!--Let browser know website is optimized for mobile-->
    	<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Halaman Login</title>
	<style>
	body {
		background-color: #80cbc4;
	}

	.container {
		width: 500px;
		padding: 30px;
	}

	.card-panel {
		background-color: #d8d8d8;
		box-shadow: 8px 8px 8px #607d8b;
	}

	.salah {
		color: red;
		font-style: italic;
		text-align: center;
	}

	.admin {
		font-style: italic;
		text-align: center;
		font-size: 12px;
		color: black;
	}

	img {
		width: 100px;
		display: block;
		margin: auto;
	}
	</style>
</head>
<body>
<div class="container">
	<div class="col s6">
        <form action="" method="post">
        	<div class="card-panel">
                <h5 align="center">Login as Admin</h5>
                <img src="../assets/images/user.png">

                <br>

                <?php if( isset($error)) : ?>
					<p class="salah"> Username/Password anda Salah</p>
					<br>
				<?php endif; ?>

                  <div class="input-field">
                  	<i class="material-icons prefix">person</i>
                  	<input type="text" name="username" id="username" autofocus="" autocomplete="off">
                    <label for="username">Username</label>
                  </div>

                  <div class="input-field">
                  	<i class="material-icons prefix">https</i>
                  	<input type="password" name="password" id="password" autofocus="" autocomplete="off">
                    <label for="password">Password</label>
				  </div>
				  <br>

                  <button type="sumbit" name="submit" class="btn blue darken-2">Login</button>

                  <p class="admin">login : admin/admin</p>

            </div>
        </form>
    </div>
</div>

<!--JavaScript at end of body for optimized loading-->
<script type="text/javascript" src="../js/materialize.min.js"></script>

</body>
</html>