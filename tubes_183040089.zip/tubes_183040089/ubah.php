<?php

	require 'functions.php';

	$id = $_GET["id"];

	$hp = query("SELECT * FROM smartphone WHERE id = $id")[0];

	if( isset($_POST["ubah"]) ) {
	
	// cek apakah data berhasil di ubah atau tidak
	if( ubah($_POST) > 0 ) {
		echo "
			<script>
				alert('data berhasil diubah!');
				document.location.href = 'admin/index.php';
			</script>
		";
	} else {
		echo "
			<script>
				alert('data gagal diubah!');
				document.location.href = 'admin/index.php';
			</script>
		";
	}
}

?>


<!DOCTYPE html>
<html>
<head>
	<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
	<title>Ubah Data Smartphone</title>
	<style>
		h1 {
			text-align: center;
			font-family: forte;
		}

		body {
			background-color: #bdbdbd;
			padding: 20px;
		}

		.card-panel {
			background-color: #FFFAF0;
			box-shadow: 0px 0px 10px black;
		}
	</style>
</head>
<body>

<div class="container">
	<div class="col s6">
        <form action="" method="post" enctype="multipart/form-data">
        	<div class="card-panel">
			<h1>Ubah Data Smartphone</h1>

			<input type="hidden" name="id" value="<?= $hp["id"]; ?>">
			<input type="hidden" name="gambarLama" value="<?= $hp["Gambar"]; ?>">
		
			<label for="Nama_Smartphone">Nama Smartphone</label>
			<input type="text" name="Nama_Smartphone" id="Nama_Smartphone" required value="<?= $hp["Nama_Smartphone"]; ?>"><br><br>

			<label for="Gambar">Gambar</label><br>
			<img src="assets/images/<?= $hp['Gambar']; ?>" width="150"><br>
			<input type="file" name="Gambar" id="Gambar"><br><br>

			<label for="Warna">Warna</label>
			<input type="text" name="Warna" id="Warna" required value="<?= $hp["Warna"]; ?>"><br><br>

			<label for="Ukuran_Layar">Ukuran Layar</label>
			<input type="text" name="Ukuran_Layar" id="Ukuran_Layar" required value="<?= $hp["Ukuran_Layar"]; ?>"><br><br>

			<label for="Berat">Berat</label>
			<input type="text" name="Berat" id="Berat" required value="<?= $hp["Berat"]; ?>"><br><br>

			<label for="Tahun_Rilis">Tahun Rilis</label> :
			<input type="text" name="Tahun_Rilis" id="Tahun_Rilis" required value="<?= $hp["Tahun_Rilis"]; ?>"><br><br>

			<label for="Harga">Harga</label>
			<input type="text" name="Harga" id="Harga" required value="<?= $hp["Harga"]; ?>"><br><br><br>

			<button type="sumbit" name="ubah" id="ubah" class="btn blue darken-2">Ubah Data</button>
			<a href="admin/index.php" class="btn blue darken-2">Kembali</a>
		</form>

	<!--JavaScript at end of body for optimized loading-->
    <script type="text/javascript" src="js/materialize.min.js"></script>

</body>
</html>