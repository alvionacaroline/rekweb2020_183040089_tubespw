-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2019 at 03:34 PM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pw_183040089`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `id` int(11) NOT NULL,
  `nama` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `jurusan` varchar(64) NOT NULL,
  `universitas` varchar(64) NOT NULL,
  `gambar` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`id`, `nama`, `email`, `jurusan`, `universitas`, `gambar`) VALUES
(1, 'Fahmi Ramadhan', 'fahmi@mail.unpas.ac.id', 'informatika', 'pasundan', 'fahmi.png'),
(2, 'tanti yuliawati', 'tanti@mail.unpas.ac.id', 'informatika', 'pasundan', 'tanti.png');

-- --------------------------------------------------------

--
-- Table structure for table `smartphone`
--

CREATE TABLE `smartphone` (
  `id` int(10) NOT NULL,
  `Nama_Smartphone` varchar(30) NOT NULL,
  `Gambar` varchar(30) NOT NULL,
  `Warna` varchar(30) NOT NULL,
  `Ukuran_Layar` varchar(30) NOT NULL,
  `Berat` varchar(30) NOT NULL,
  `Tahun_Rilis` year(4) NOT NULL,
  `Harga` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `smartphone`
--

INSERT INTO `smartphone` (`id`, `Nama_Smartphone`, `Gambar`, `Warna`, `Ukuran_Layar`, `Berat`, `Tahun_Rilis`, `Harga`) VALUES
(1, 'Iphone XS Max', 'smartphone1.png', 'Gold', '6.5 inches', '208 gram', 2018, 'Rp. 22.499.000'),
(2, 'Samsung S10+', 'smartphone2.png', 'Ceramic Black', '6.4 inches', '175 gram', 2019, 'Rp. 12.999.000'),
(3, 'Oppo F9', 'smartphone3.png', 'Sunrise Red', '6.3 inches', '169 gram', 2018, 'Rp. 3.648.000'),
(4, 'Vivo V15', 'smartphone4.png', 'Royal Blue', '6.53 inches', '189.5 gram', 2019, 'Rp. 4.099.000'),
(5, 'Huawei Mate 20 Pro', 'smartphone5.png', 'Twilight', '6.39 inches', '189 gram', 2018, 'Rp. 11.799.000'),
(6, 'Xiaomi Pocophone F1', 'smartphone6.png', 'Steel Blue', '6.18 inches', '182 gram', 2018, 'Rp. 3.725.000'),
(7, 'LG G7+ ThinQ', 'smartphone7.png', 'Platinum Gray', '6.1 inches', '162 gram', 2018, 'Rp. 8.950.000'),
(8, 'Samsung Galaxy S9', 'smartphone8.png', 'Lilac Purple', '5.8 inches', '163 gram', 2018, 'Rp. 8.930.000'),
(9, 'Iphone 8+', 'smartphone9.png', 'Space Gray', '5.5 inches', '202 gram', 2017, 'Rp. 11.499.000'),
(10, 'Oppo Find X', 'smartphone10.png', 'Glacier Blue', '6.4 inches', '186 gram', 2018, 'Rp. 10.849.000');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(16) NOT NULL,
  `password` varchar(256) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `created_at`) VALUES
(1, 'admin', 'admin', '2019-04-20 06:44:05');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD KEY `id` (`id`);

--
-- Indexes for table `smartphone`
--
ALTER TABLE `smartphone`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `smartphone`
--
ALTER TABLE `smartphone`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
