<?php 

require 'functions.php';

if(isset($_POST["cari"]) ) {
	$smartphone = cari($_POST["keyword"]);
} else {
  $smartphone = query("SELECT * FROM smartphone");
}

?>


<!DOCTYPE html>
<html>
<head>
	<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>

      <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>

	<title>Halaman User</title>
	<style>
		body {
			background-color: #9e9e9e;
		}
		a {
			font-family: arial;
			text-decoration: none;
		}

		a:hover {
			color: #eeeeee;
		}

		.container1 {
			width: 600px;
   			margin: 15px auto;
   		 	padding: 15px;
    		box-shadow: 0 0 40px #d8d8d8;
    		border-radius: 15px;
    		text-align: center;
    		background-color: #263238;
		}

		img:hover {
			box-shadow: 0 0 5px #d8d8d8;
		}

		h1 {
			font-family: forte;
			color: black;
		}

		.nama {
			color: #757575;
			font-family: arial;
			font-size: 25px;
			text-decoration: none;
		}

		.nama:hover {
			color: white;
		}

    .data {
      text-align: center;
      font-family: arial;
      color: red;
      font-style: italic;
      padding: 10px;
      background-color: white;
      width: 500px;
      margin: auto;
      border-radius: 8px;
      box-shadow: 5px 5px 5px black;
    }
	</style>
</head>
<body>

<!-- navbar -->
    <div class="navbar-fixed">
      <nav class="#424242 grey darken-3">
        <div class="container">
          <div class="nav-wrapper">

            <ul class="brand-logo center">
         	    <li>
         	      <a href="index.php"><i class="material-icons">home</i></a>
         	    </li>
         	  </ul>
         	
            <ul class="right hide-on-med-and-down">
         	    <li><i class="material-icons">input</i></li>
              <li><a class="login" href="admin/admin.php">Login as Admin</a></li>
         	  </ul>
         	
            <ul class="left hide-on-med-and-down">
         	    <li>
                <form action="" method="post" class="search">
             			<i class="material-icons">search
                    <input type="text" name="keyword" autofocus placeholder="Search..." autocomplete="off"></i>
                    <button type="submit" name="cari" style="display: none;">Cari</button>
		            </form>
              </li>
           	</ul>
          </div>
        </div>
      </nav>
    </div>
<!-- Tutup navbar -->

    <li><a href="admin/admin.php">Login as Admin</a></li>  


      <h1 align="center">Macam-Macam Smartphone</h1>

      <?php if (empty($smartphone)) :?>
        <tr>
          <td>
            <h3 class="data">Data Tidak Ditemukan!</h3>
          </td>
        </tr>
      <?php else : ?>

      <div class="container1">

      <?php foreach ($smartphone as $hp): ?>

      	<p><a href="profil.php?id=<?=$hp['id']; ?>"><img align="center" src="assets/images/<?= $hp['Gambar'] ?>"></a></p>
      	<p><a class="nama" href="profil.php?id=<?=$hp['id']; ?>"><?php echo $hp['Nama_Smartphone']; ?></a></p>
      	<br>
      <?php endforeach ?>
      <?php endif ?>
      </div>

  <!--JavaScript at end of body for optimized loading-->
  <script type="text/javascript" src="js/materialize.min.js"></script>

</body>
</html>